

# Tower builder #
## by David Hempston ##
Phaser/JS and testing on django, aws/python step.

## Current build ##

### Version 0.302 ###
Bug fixes
* Flat 3 would use tile 2 from flat 2
* Tiles could overlay off the marker tiler

*Version 0.3 29/08/2016
Added:
-Multi-tile system
-Flat 1/2/3 tile images

*Version 0.2 29/08/2016
Added:
-Money system

*Version 0.1 28/08/2016
Added
-Basic single tile color blocks placement

## Planned ideas ##

test
beep
food: low/high
entertainment: cinema/theater
stairs/lifts

Hazzards: fire/flood/crime

## Contact ##

cyber_veio@hotmail.com
